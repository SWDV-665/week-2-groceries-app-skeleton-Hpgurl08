import React, { useState } from "react";
import {
  IonContent,
  IonHeader,
  IonPage,
  IonTitle,
  IonToolbar,
  IonButton,
  IonModal,
  IonIcon,
  IonInput,
} from "@ionic/react";
import { add } from "ionicons/icons";
import GroceryList from "../components/GroceryList";

const Grocery: React.FC = () => {
  const [groceryItems, setGroceryItems] = useState<string[]>([
    "Apples",
    "Bananas",
    "Milk",
    "Bread",
    "Eggs",
  ]);
  const [newItem, setNewItem] = useState<string>("");
  const [showPopup, setShowPopup] = useState(false);

  const addItemToList = () => {
    if (newItem.trim() !== "") {
      setGroceryItems([newItem, ...groceryItems]);
      setNewItem("");
      // Close the popup after adding the item
      setShowPopup(false);
    }
  };

  const removeItemFromList = (index: number) => {
    const updatedItems = [...groceryItems];
    updatedItems.splice(index, 1);
    setGroceryItems(updatedItems);
  };

  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonTitle className="title">Groceries List</IonTitle>
          <IonButton slot="end" onClick={() => setShowPopup(true)}>
            <IonIcon icon={add} />
          </IonButton>
        </IonToolbar>
      </IonHeader>
      <IonContent fullscreen>

      {/*import GroceryList component*/}
        <GroceryList 
        groceryItems={groceryItems} 
        removeItemFromList={removeItemFromList}
        />
        <IonModal isOpen={showPopup}>
          <IonContent className="center-content">
            <IonToolbar>
              <IonButton slot="end" onClick={() => setShowPopup(false)}>
                X
              </IonButton>
            </IonToolbar>
            <div className="form-container">
              <IonInput
                type="text"
                placeholder="Enter a new item"
                value={newItem}
                onIonChange={(e) => setNewItem(e.detail.value!)}
              />
              <IonButton expand="block" onClick={addItemToList}>
                Add
              </IonButton>
            </div>
          </IonContent>
        </IonModal>
      </IonContent>
    </IonPage>
  );
};

export default Grocery;
