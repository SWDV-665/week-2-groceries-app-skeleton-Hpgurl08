import React from "react";
import {
  IonList,
  IonItem,
  IonLabel,
  IonButton,
} from "@ionic/react";

interface GroceryListProps {
  groceryItems: string[];
  removeItemFromList: (index: number) => void;
}

const GroceryList: React.FC<GroceryListProps> = ({ groceryItems, removeItemFromList }) => {
  return (
    <IonList>
      {groceryItems.length === 0 ? (
        <IonItem>
          <IonLabel>No items in the list</IonLabel>
        </IonItem>
      ) : (
        groceryItems.map((item: string, index: number) => (
          <IonItem key={index}>
            <IonLabel>{item}</IonLabel>
            <IonButton
              onClick={() => removeItemFromList(index)}
              className="btn"
            >
              X
            </IonButton>
          </IonItem>
        ))
      )}
    </IonList>
  );
};

export default GroceryList;
